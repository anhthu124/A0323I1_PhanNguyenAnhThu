package com.example.phone.service;

import com.example.phone.model.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> showList();
}
