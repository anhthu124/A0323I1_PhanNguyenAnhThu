package com.example.phone.repository;

import com.example.phone.model.Category;

import java.util.List;

public interface ICategoryRepo {
    List<Category> showList();
}
